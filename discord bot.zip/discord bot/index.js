const fs = require('fs');
const Discord = require("discord.js");
const client = new Discord.Client();
const config = require("./config.json");
let gangpot = config.gangpot;
let items = JSON.parse(config.items);
let prefix = "!";


client.once('ready', () => { 
  client.user.setActivity('!gangpot', { type: "WATCHING" }); 

});

const formatItems = () => {
  let str = "";
  items.forEach((item) => {
      str += item.type + ": " + item.aantal + "\n";
  });

  if (str === "") {
    str ="Geen Items in de pot";
  }

  return str;
};

const embedFabriek = (type) => {
  let filename;

  if(type === "money") {
    filename = "money.png"
  }

  if(type === "busje") {
    filename = "busje.png"

  }

  if(type === "mesje") {
    filename = "knife.png"

  }

  if(type === "gun") {
    filename = "gun.png"

  }

  if(type === "jestki") {
    filename = "jestki.png"

  }

  else {
    filename = "noitem.png"
  }

  let e = new Discord.MessageEmbed()
      .setTitle("Informatie over de gangpot")
      .setDescription(`De gangpot bevat €${gangpot}`)
      .setColor("RANDOM")
      .addField("Items", formatItems())
      .attachFiles(["./" +filename])
      .setImage("attachment://"+filename)
      .setFooter("Lekker bezig!");

  return e;
};

client.on("message", async (message) => {
  if (message.content.startsWith(prefix)) {
      const args = message.content.slice(prefix.length).trim().split(/ +/g);
      const command = args.shift().toLowerCase();

      if (command == "ping") {
          message.channel.send("Pong!");
      }
    
  if(command === "gangpot") {
    let embed = embedFabriek ();
    message.channel.send(embed);
  }

  if(command === "addmoney") {
    let aantal = parseFloat (args[0]);
    gangpot += aantal;
    fs.writeFileSync(('./config.json'), JSON.stringify({ gangpot: gangpot, items: items}));
    let embed = embedFabriek ("money");
    message.channel.send(embed);

    
    client.channels
                .fetch("837997668684267540")
                .then((channel) =>
                    channel.send(`${message.author.username} heeft €${aantal} toegevoegd aan de gangpot.`)
                )
                .catch(console.error);
  }

  if(command === "deletemoney") {
    let aantal = parseFloat (args[0]);
    gangpot -= aantal;
    fs.writeFileSync(('./config.json'), JSON.stringify({ gangpot: gangpot, items: items}));
    let embed = embedFabriek ("money");
    message.channel.send(embed);

    client.channels
                .fetch("837997668684267540")
                .then((channel) =>
                    channel.send(`${message.author.username} heeft €${aantal} verwijderd van de gangpot.`)
                )
                .catch(console.error);
  }

  if(command === "additem") {
    let naam = args[0].toLowerCase();
    let aantal = parseFloat (args[1]);

    let gevonden = false;
    items.forEach((item) => {
      if (item.type == naam){
        item.aantal += aantal;
        gevonden = true;
      }
    });


    if (!gevonden) {
      items.push({
        type : naam,
        aantal : aantal,
      });
    }
    fs.writeFileSync(('./config.json'), JSON.stringify({ gangpot: gangpot, items: items}));

    let embed = embedFabriek (naam);
    message.channel.send(embed);

    client.channels
                .fetch("837997668684267540")
                .then((channel) =>
                    channel.send(`${message.author.username} heeft ${aantal} ${naam} toegevoegd aan de gangpot.`)
                )
                .catch(console.error);
  }

  if(command === "deleteitem") {
    let naam = args[0].toLowerCase();
    let aantal = parseFloat (args[1]);

    let gevonden = false;
    items.forEach((item) => {
      if (item.type == naam){
        item.aantal -= aantal;
        gevonden = true;
      }
    });
    if (!gevonden) {
      //items.push({
        //type : naam,
        //aantal : aantal,
      //});
        message.reply("Dit item zit niet in de gangpot!");
      
    }
    fs.writeFileSync(('./config.json'), JSON.stringify({ gangpot: gangpot, items: items}));
    let embed = embedFabriek (naam);
    message.channel.send(embed);
    
    client.channels
                .fetch("837997668684267540")
                .then((channel) =>
                    channel.send(`${message.author.username} heeft ${aantal} ${naam} verwijderd van de gangpot.`)
                )
                .catch(console.error);
  }
}
});


  


client.login("ODM3OTQ5MDg2MDgxNDgyNzYy.YIz-5g._3TOP9DgbnZnEiMKrQpoYDJDaQc");